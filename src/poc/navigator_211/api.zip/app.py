from __future__ import annotations

from fastapi import FastAPI
from .routes import router
from .bootstrap import ensure_tables

app = FastAPI(title="Navigator 211 API", version="0.1.0")
app.include_router(router)


@app.on_event("startup")
def _startup() -> None:
    ensure_tables()
    # Optional: if you added sqlite bootstrap, keep this.
    try:
        from .sqlite_bootstrap import bootstrap_sqlite
        bootstrap_sqlite()
    except Exception:
        # Don't prevent startup if bootstrap file doesn't exist yet
        pass
