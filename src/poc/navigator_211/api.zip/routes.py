from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Mapping

from fastapi import APIRouter, HTTPException
from sqlalchemy import text

from .db import engine
from .models import HealthResponse, IntakeCreate, IntakeResponse

router = APIRouter()


# -----------------------
# Helpers
# -----------------------
def _to_bool(v: Any) -> bool:
    # SQLite often returns 0/1 for booleans
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    if isinstance(v, (int, float)):
        return bool(int(v))
    if isinstance(v, str):
        s = v.strip().lower()
        if s in ("1", "true", "t", "yes", "y", "on"):
            return True
        if s in ("0", "false", "f", "no", "n", "off", ""):
            return False
        return True
    return bool(v)


def _parse_json(v: Any) -> Any:
    import json

    if v is None:
        return None
    if isinstance(v, (dict, list)):
        return v
    if not isinstance(v, str):
        return v
    s = v.strip()
    if not s:
        return None
    try:
        return json.loads(s)
    except Exception:
        return v


def _safe_json(obj: Any) -> str:
    import json

    if obj is None:
        obj = {}
    return json.dumps(obj, ensure_ascii=False)


def _shape_intake_list_row(row: Mapping[str, Any]) -> Dict[str, Any]:
    d = dict(row)
    if "crisis" in d:
        d["crisis"] = _to_bool(d["crisis"])
    return d


def _shape_intake_detail_row(row: Mapping[str, Any]) -> Dict[str, Any]:
    d = dict(row)
    if "Crisis" in d:
        d["Crisis"] = _to_bool(d["Crisis"])
    if "AttributesJson" in d:
        d["AttributesJson"] = _parse_json(d["AttributesJson"])
    return d


def _evaluate_rules_sqlite(payload: IntakeCreate) -> tuple[str, str, List[Dict[str, Any]]]:
    """
    Local (SQLite) routing rules:
    - crisis true => Crisis
    - priority High/Critical => Priority
    - else => payload.domain_module
    """
    if payload.crisis:
        queue = "Crisis"
        reason = "Crisis flag is true"
        applied = [{"rule": "crisis_flag", "action": "route", "queue": queue}]
        return queue, reason, applied

    pr = (payload.priority or "").strip().lower()
    if pr in ("high", "critical"):
        queue = "Priority"
        reason = f"Priority is {payload.priority}"
        applied = [{"rule": "priority_high", "action": "route", "queue": queue}]
        return queue, reason, applied

    queue = payload.domain_module
    reason = "Auto-routed"
    applied = [{"rule": "default_domain", "action": "route", "queue": queue}]
    return queue, reason, applied


# -----------------------
# Health check
# -----------------------
@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    if engine is None:
        return HealthResponse(status="ok", db="not_configured", version="0.1.0")

    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return HealthResponse(status="ok", db="ok", version="0.1.0")
    except Exception as e:
        return HealthResponse(status="ok", db=f"error: {type(e).__name__}", version="0.1.0")


# -----------------------
# Create intake
# -----------------------
@router.post("/intakes", response_model=IntakeResponse)
def create_intake(payload: IntakeCreate) -> IntakeResponse:
    if engine is None:
        raise HTTPException(status_code=500, detail="DB not configured")

    created_at = datetime.utcnow()

    try:
        with engine.begin() as conn:
            # 1) Insert Intake
            conn.execute(
                text(
                    """
                    INSERT INTO Intake
                    (CreatedAt, CallerId, Channel, DomainModule, Priority, Crisis, Narrative, AttributesJson)
                    VALUES
                    (:CreatedAt, :CallerId, :Channel, :DomainModule, :Priority, :Crisis, :Narrative, :AttributesJson)
                    """
                ),
                {
                    "CreatedAt": created_at.isoformat(),
                    "CallerId": payload.caller_id,
                    "Channel": payload.channel,
                    "DomainModule": payload.domain_module,
                    "Priority": payload.priority,
                    "Crisis": 1 if payload.crisis else 0,
                    "Narrative": payload.narrative,
                    "AttributesJson": _safe_json(payload.attributes),
                },
            )

            intake_id = int(conn.execute(text("SELECT last_insert_rowid()")).scalar_one())

            # 2) Evaluate + enqueue
            rules_applied: List[Dict[str, Any]] = []
            queue_name: str
            reason: str

            if engine.dialect.name == "sqlite":
                queue_name, reason, rules_applied = _evaluate_rules_sqlite(payload)

                conn.execute(
                    text(
                        """
                        INSERT INTO QueueItem
                        (IntakeId, QueueName, Status, Reason, CreatedAt)
                        VALUES
                        (:IntakeId, :QueueName, :Status, :Reason, :CreatedAt)
                        """
                    ),
                    {
                        "IntakeId": intake_id,
                        "QueueName": queue_name,
                        "Status": "New",
                        "Reason": reason,
                        "CreatedAt": created_at.isoformat(),
                    },
                )
            else:
                # MSSQL path: try to use your existing rules_engine (dbo.* tables)
                try:
                    from .rules_engine import evaluate_rules_and_enqueue  # type: ignore

                    queue_name, reason_opt, rules_applied = evaluate_rules_and_enqueue(conn, intake_id)
                    reason = reason_opt or "Auto-routed"
                except Exception:
                    # Fallback if rules engine not compatible
                    queue_name, reason, rules_applied = _evaluate_rules_sqlite(payload)

                    conn.execute(
                        text(
                            """
                            INSERT INTO QueueItem
                            (IntakeId, QueueName, Status, Reason, CreatedAt)
                            VALUES
                            (:IntakeId, :QueueName, :Status, :Reason, :CreatedAt)
                            """
                        ),
                        {
                            "IntakeId": intake_id,
                            "QueueName": queue_name,
                            "Status": "New",
                            "Reason": reason,
                            "CreatedAt": created_at.isoformat(),
                        },
                    )

        return IntakeResponse(
            intake_id=intake_id,
            created_at=created_at,
            domain_module=payload.domain_module,
            priority=payload.priority,
            crisis=payload.crisis,
            queue=queue_name,
            reason=reason,
            rules_applied=rules_applied or [],
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# -----------------------
# List intakes
# -----------------------
@router.get("/intakes")
def list_intakes(limit: int = 50):
    if engine is None:
        return {"count": 0, "items": []}

    with engine.begin() as conn:
        # Pick the latest QueueItem per Intake (avoids duplicates)
        rows = conn.execute(
            text(
                """
                SELECT
                    i.IntakeId      AS intake_id,
                    i.CreatedAt     AS created_at,
                    i.DomainModule  AS domain_module,
                    i.Priority      AS priority,
                    i.Crisis        AS crisis,
                    q.QueueName     AS queue,
                    q.Reason        AS reason
                FROM Intake i
                LEFT JOIN QueueItem q
                  ON q.QueueItemId = (
                        SELECT MAX(qq.QueueItemId)
                        FROM QueueItem qq
                        WHERE qq.IntakeId = i.IntakeId
                  )
                ORDER BY i.IntakeId DESC
                LIMIT :limit
                """
            ),
            {"limit": limit},
        ).mappings().all()

    items = [_shape_intake_list_row(r) for r in rows]
    return {"count": len(items), "items": items}


# -----------------------
# Get single intake
# -----------------------
@router.get("/intakes/{intake_id}")
def get_intake(intake_id: int):
    if engine is None:
        raise HTTPException(status_code=500, detail="DB not configured")

    with engine.begin() as conn:
        row = conn.execute(
            text(
                """
                SELECT
                    i.*,
                    q.QueueName AS queue,
                    q.Reason AS reason,
                    q.Status AS queue_status
                FROM Intake i
                LEFT JOIN QueueItem q
                  ON q.QueueItemId = (
                        SELECT MAX(qq.QueueItemId)
                        FROM QueueItem qq
                        WHERE qq.IntakeId = i.IntakeId
                  )
                WHERE i.IntakeId = :id
                """
            ),
            {"id": intake_id},
        ).mappings().first()

    if not row:
        raise HTTPException(status_code=404, detail="not found")

    return _shape_intake_detail_row(row)


# -----------------------
# List queues
# -----------------------
@router.get("/queues")
def list_queues() -> List[Dict[str, Any]]:
    if engine is None:
        return []

    with engine.connect() as conn:
        rows = conn.execute(text("SELECT * FROM QueueItem ORDER BY QueueItemId DESC")).mappings().all()
        return [dict(r) for r in rows]
