from __future__ import annotations

from typing import Any, Dict, List, Tuple
from sqlalchemy import text


def evaluate_rules_and_enqueue(conn, intake_id: int) -> Tuple[str, str | None, List[Dict[str, Any]]]:
    """
    Minimal rules evaluator:
    - If Intake.Crisis = 1 => queue 'Crisis'
    - Else if Priority in ('High','Critical') => queue 'Priority'
    - Else => queue 'General'
    Writes QueueItem row and returns (queue, reason, rules_applied)
    """
    row = conn.execute(
        text("SELECT Crisis, Priority, DomainModule FROM dbo.Intake WHERE IntakeId = :id"),
        {"id": intake_id},
    ).mappings().first()

    if not row:
        return ("General", "Intake not found", [])

    crisis = bool(row["Crisis"])
    priority = (row["Priority"] or "").strip()

    if crisis:
        queue = "Crisis"
        reason = "Crisis flag is true"
        applied = [{"rule": "crisis_flag", "action": "route", "queue": queue}]
    elif priority.lower() in ("high", "critical"):
        queue = "Priority"
        reason = f"Priority is {priority}"
        applied = [{"rule": "priority_high", "action": "route", "queue": queue}]
    else:
        queue = "General"
        reason = "Default routing"
        applied = [{"rule": "default", "action": "route", "queue": queue}]

    # Ensure QueueItem table exists; if not, raise a clear error
    conn.execute(
        text("""
            INSERT INTO dbo.QueueItem (IntakeId, QueueName, Status, Reason, CreatedAt)
            VALUES (:IntakeId, :QueueName, 'New', :Reason, SYSUTCDATETIME())
        """),
        {"IntakeId": intake_id, "QueueName": queue, "Reason": reason},
    )

    return (queue, reason, applied)
